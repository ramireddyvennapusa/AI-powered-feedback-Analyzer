
import React from 'react';
import type { AnalysisResult } from '../types';
import TagIcon from './icons/TagIcon';
import LightBulbIcon from './icons/LightBulbIcon';
import CheckCircleIcon from './icons/CheckCircleIcon';
import XCircleIcon from './icons/XCircleIcon';


const sentimentStyles = {
  Positive: {
    bgColor: 'bg-green-100 dark:bg-green-900',
    textColor: 'text-green-800 dark:text-green-200',
    borderColor: 'border-green-500 dark:border-green-600',
    icon: <CheckCircleIcon className="h-6 w-6 text-green-500" />
  },
  Negative: {
    bgColor: 'bg-red-100 dark:bg-red-900',
    textColor: 'text-red-800 dark:text-red-200',
    borderColor: 'border-red-500 dark:border-red-600',
    icon: <XCircleIcon className="h-6 w-6 text-red-500" />
  },
  Neutral: {
    bgColor: 'bg-yellow-100 dark:bg-yellow-900',
    textColor: 'text-yellow-800 dark:text-yellow-200',
    borderColor: 'border-yellow-500 dark:border-yellow-600',
    icon: <div className="h-5 w-5 bg-yellow-500 rounded-full" />
  },
  Mixed: {
    bgColor: 'bg-blue-100 dark:bg-blue-900',
    textColor: 'text-blue-800 dark:text-blue-200',
    borderColor: 'border-blue-500 dark:border-blue-600',
    icon: <div className="h-5 w-5 bg-blue-500 rounded-full" />
  },
};

const Card: React.FC<{ children: React.ReactNode; className?: string }> = ({ children, className = '' }) => (
  <div className={`bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg ${className}`}>
    {children}
  </div>
);

const AnalysisResults: React.FC<{ result: AnalysisResult }> = ({ result }) => {
  const sentiment = result.sentiment || 'Neutral';
  const styles = sentimentStyles[sentiment];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-center text-gray-800 dark:text-white">Analysis Results</h2>

      {/* Sentiment */}
      <Card className={`border-l-4 ${styles.borderColor}`}>
        <div className="flex items-center">
          {styles.icon}
          <div className="ml-4">
            <h3 className="text-sm font-medium text-gray-500 dark:text-gray-400">Overall Sentiment</h3>
            <p className={`text-xl font-semibold ${styles.textColor}`}>{sentiment}</p>
          </div>
        </div>
      </Card>
      
      {/* Summary */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">Summary</h3>
        <p className="text-gray-600 dark:text-gray-300">{result.summary}</p>
      </Card>

      {/* Key Themes */}
      <Card>
        <div className="flex items-center mb-4">
          <TagIcon className="h-6 w-6 text-blue-500 mr-3" />
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Key Themes</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {result.key_themes.map((theme, index) => (
            <span key={index} className="px-3 py-1 text-sm font-medium text-blue-800 bg-blue-100 dark:bg-blue-900 dark:text-blue-200 rounded-full">
              {theme}
            </span>
          ))}
        </div>
      </Card>
      
      {/* Actionable Insights */}
      <Card>
        <div className="flex items-center mb-4">
          <LightBulbIcon className="h-6 w-6 text-yellow-500 mr-3" />
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Actionable Insights</h3>
        </div>
        <ul className="space-y-3">
          {result.actionable_insights.map((insight, index) => (
            <li key={index} className="flex items-start">
              <CheckCircleIcon className="h-5 w-5 text-green-500 mt-1 mr-3 flex-shrink-0" />
              <span className="text-gray-600 dark:text-gray-300">{insight}</span>
            </li>
          ))}
        </ul>
      </Card>
    </div>
  );
};

export default AnalysisResults;
