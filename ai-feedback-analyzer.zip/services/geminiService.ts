
import { GoogleGenAI, Type } from "@google/genai";
import type { AnalysisResult } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    sentiment: {
      type: Type.STRING,
      description: "The overall sentiment of the feedback. Must be one of: 'Positive', 'Negative', 'Neutral', or 'Mixed'.",
      enum: ['Positive', 'Negative', 'Neutral', 'Mixed'],
    },
    summary: {
      type: Type.STRING,
      description: "A concise, one to two-sentence summary of the entire feedback text."
    },
    key_themes: {
      type: Type.ARRAY,
      description: "A list of 2 to 5 main topics or themes mentioned in the feedback. For example: 'Customer Support', 'Pricing', or 'Feature Request'.",
      items: { type: Type.STRING }
    },
    actionable_insights: {
      type: Type.ARRAY,
      description: "A list of 2 to 3 specific, actionable suggestions for improvement based on the feedback. Each insight should be a clear, direct recommendation.",
      items: { type: Type.STRING }
    }
  },
  required: ["sentiment", "summary", "key_themes", "actionable_insights"]
};

export const analyzeFeedback = async (feedbackText: string): Promise<AnalysisResult> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analyze the following customer feedback and provide a structured analysis. Here is the feedback: "${feedbackText}"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2,
      },
       systemInstruction: "You are an expert feedback analyst. Your role is to dissect customer feedback and provide a structured, objective analysis based on the provided schema. Focus on extracting factual themes and providing practical, actionable advice."
    });

    const jsonText = response.text;
    if (!jsonText) {
        throw new Error("API returned an empty response.");
    }

    // Sanitize the response text before parsing
    const cleanedJsonText = jsonText.replace(/```json|```/g, '').trim();

    const result: AnalysisResult = JSON.parse(cleanedJsonText);
    return result;

  } catch (error) {
    console.error("Error analyzing feedback with Gemini:", error);
    throw new Error("Failed to get analysis from the AI service.");
  }
};
